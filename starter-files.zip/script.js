const button = document.querySelector("#helloButton");
const message = document.querySelector("#message");

button.addEventListener("click", () => {
  message.textContent = "Отлично! Ты только что добавил интерактивность с JavaScript.";
});